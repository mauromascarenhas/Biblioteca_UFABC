package com.nintersoft.bibliotecaufabc.jsinterface;

import android.content.Context;
import android.webkit.JavascriptInterface;

import com.nintersoft.bibliotecaufabc.SearchActivity;

public class SearchJSInterface {
    private Context mContext;

    public SearchJSInterface(Context context){
        mContext = context;
    }

    @JavascriptInterface
    public void setSearchResults(final String results){
        ((SearchActivity) mContext).runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ((SearchActivity)mContext).setupInterface(true);
                ((SearchActivity)mContext).setSearchResults(results);
            }
        });
    }

    @JavascriptInterface
    public void addSearchResults(String addResults){
        //TODO : set on SearchActivity
    }
}
