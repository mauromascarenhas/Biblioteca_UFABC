package com.nintersoft.bibliotecaufabc.jsinterface;

import android.content.Context;
import android.util.Log;
import android.webkit.JavascriptInterface;

import com.nintersoft.bibliotecaufabc.LoginActivity;

public class LoginJSInterface {
    private Context mContext;

    public LoginJSInterface(Context context){
        mContext = context;
    }

    @JavascriptInterface
    public void setUserName(String username){
        if(!username.isEmpty()) ((LoginActivity)mContext).hasLoggedIn(username);
    }

    @JavascriptInterface
    public void showError(boolean hasError, String details){
        if (!hasError) return;
        ((LoginActivity)mContext).showLoginError(details);
    }
}
