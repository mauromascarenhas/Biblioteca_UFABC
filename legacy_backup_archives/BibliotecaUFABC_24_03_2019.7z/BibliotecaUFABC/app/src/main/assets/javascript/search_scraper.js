// Objects which stores the last search params
var searchOptions;

// Selectable input references
var searchFields;
var searchFilters;
var searchLibraries;

// Input references
var searchButton;
var searchEditor;

// Triggered as soon as DOM elements are available
function documentReady(){
  // Bind input references
  searchEditor = document.querySelector("#searc-basic");
  searchButton = document.querySelector("#bbotaobuscar").getElementsByTagName("input")[0];

  // Binds selectable input references
  searchFields = document.querySelector('select[name="bselcampo"]').getElementsByTagName("option");
  searchFilters = document.querySelector("#bselmaterial").getElementsByTagName("option");
  searchLibraries = document.querySelector("#bselbiblioteca").getElementsByTagName("option");

  searchOptions = {
    field : 0,
    filters : new Array(searchFilters.length),
    libraries : new Array(searchLibraries.length)
  };

  searchOptions.filters[0] = true;
  for (let i = 1; i < searchOptions.filters.length; ++i)
    searchOptions.filters[i] = false;

  searchOptions.libraries[0] = true;
  for (let i = 1; i < searchOptions.libraries.length; ++i)
    searchOptions.libraries[i] = false;
}

function setSearchFilter(filter){
  if (filter.field == null || filter.filters == null || filter.libraries == null || !isReady)
    return false;

  for (let i = 0; i < searchFields.length; ++i)
    if (filter.field == i && !searchFields[i].hasAttribute("selected"))
      searchFields[i].setAttribute("selected", "");
    else if (filter.field != i && searchFields[i].hasAttribute("selected"))
      searchFields[i].removeAttribute("selected", "");

  for (let i = 0; i < searchFilters.length; ++i)
    if (filter.filters[i] && !searchFilters[i].hasAttribute("selected"))
      searchFilters[i].setAttribute("selected", "");
    else if (filter.filters[i] && searchFilters[i].hasAttribute("selected"))
      searchFilters[i].removeAttribute("selected", "");

  for (let i = 0; i < searchLibraries.length; ++i)
    if (filter.libraries[i] && !searchLibraries[i].hasAttribute("selected"))
      searchLibraries[i].setAttribute("selected", "");
    else if (filter.libraries[i] && searchLibraries[i].hasAttribute("selected"))
      searchLibraries[i].removeAttribute("selected", "");

  searchOptions = filter;
  return true;
}

// Returns the current search filters (not necessarily applied)
function getSearchFilter(){
  return JSON.stringify(searchOptions);
}

// Performs a search with the given query
function performSearch(query){
  searchEditor.value = query;
  searchButton.click();
}

// Get search results
function getSearchResults(){
    var list = document.getElementById('lista').getElementsByTagName('li');
    var results = new Array(list.length - 2);

    for (let i = 1; i < list.length - 1; ++i){
      let nodeElement = list[i];
      let nodeProperties = list[i].getElementsByTagName('p');

      let bookElement = {
        title : nodeProperties[0].getElementsByClassName('tituloResultadoBusca')[0].innerHTML,
        author : nodeProperties[1].innerHTML,
        type : nodeProperties[2].innerHTML,
        section : nodeProperties[3].innerHTML
      };

      results[i - 1] = bookElement;
    }

    //Human readable JSON (for debug purposes)
    js_api.setSearchResults(JSON.stringify(results, null, 4));
}

// Get labels for filters dynamically

/*function getOptionsLabel(){
  let labels = {
    fields : new Array(searchFields.length),
    filters : new Array(searchFilters.length),
    libraries : new Array(searchLibraries.length)
  };

  for (let i = 0; i < labels.fields.length; ++i)
    labels.fields[i] = searchFields[i].innerHTML;

  for (let i = 0; i < labels.filters.length; ++i)
    labels.filters[i] = searchFilters[i].innerHTML;

  for (let i = 0; i < labels.libraries.length; ++i)
    labels.libraries[i] = searchLibraries[i].innerHTML;

  return labels;
}*/