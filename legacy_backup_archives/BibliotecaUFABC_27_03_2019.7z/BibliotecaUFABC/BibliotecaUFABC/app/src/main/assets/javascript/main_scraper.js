function getNewestBooks(){
    var list = document.getElementById('lista').getElementsByTagName('li');
    var results = new Array(list.length - 2);

    for (let i = 1; i < list.length - 1; ++i){
      let nodeElement = list[i];
      let nodeProperties = list[i].getElementsByTagName('p');

      let bookElement = {
        title : nodeProperties[0].getElementsByClassName('tituloResultadoBusca')[0].innerHTML,
        author : nodeProperties[1].innerHTML,
        type : nodeProperties[2].innerHTML,
        section : nodeProperties[3].innerHTML,
        code : new URL(list[i].getElementsByTagName('a')[0].href).searchParams.get('codigo')
      };

      results[i - 1] = bookElement;
    }

    //Human readable JSON (for debug purposes)
    js_api.setBooks(JSON.stringify(results, null, 4));
}