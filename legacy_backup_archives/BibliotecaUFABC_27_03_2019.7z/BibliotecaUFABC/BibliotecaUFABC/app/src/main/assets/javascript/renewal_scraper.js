function getRenewals(){
    //TODO: Do whatever I have to do here!
}