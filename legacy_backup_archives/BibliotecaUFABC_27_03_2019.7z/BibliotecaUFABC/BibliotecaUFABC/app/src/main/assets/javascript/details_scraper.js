function getBookDetails(){
    var properties_list = document.querySelector('.tabelaDetalhe');

    var bookDetails = {
        code : "",
        title : "",
        author : "",
        properties : null,
        media : null,
        exists : properties_list != null
    };

    if (properties_list == null)
        return bookDetails;

    bookDetails.code = new URL(window.location.href).searchParams.get('codigo');

    var titleNode = document.querySelector('.textoDescricao');
    if (titleNode != null)
        bookDetails.title = titleNode.innerHTML;

    var authorNode = document.querySelector('.textoAutorDetalhe');
    if (authorNode != null)
            bookDetails.author = authorNode.innerHTML;

    var property_rows = properties_list.getElementsByTagName('tr');
    bookDetails.properties = new Array(property_rows.length);
    for (let i = 0; i < property_rows.length; ++i){
        let properties = {
            title : property_rows[i].getElementsByTagName('td')[0].innerHTML,
            description : property_rows[i].getElementsByTagName('td')[1].innerHTML
        };
        bookDetails.properties[i] = properties;
    }

    js_api.setBookDetails(JSON.stringify(bookDetails, null, 4));
}
