package com.nintersoft.bibliotecaufabc;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.nintersoft.bibliotecaufabc.constants.GlobalConstants;
import com.nintersoft.bibliotecaufabc.jsinterface.DetailsJSInterface;
import com.nintersoft.bibliotecaufabc.webviewclients.DetailsWebClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;

public class BookViewerActivity extends AppCompatActivity {

    @SuppressLint("StaticFieldLeak")
    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView bmImage;

        DownloadImageTask(ImageView bmImage) {
            this.bmImage = bmImage;
        }

        protected Bitmap doInBackground(String... urls) {
            String urlDisplay = urls[0];
            Bitmap mIcon11 = null;
            try {
                InputStream in = new java.net.URL(urlDisplay).openStream();
                mIcon11 = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
            return mIcon11;
        }

        protected void onPostExecute(Bitmap result) {
            if (result != null)
                bmImage.setImageBitmap(result);
        }
    }

    private String bookData;

    private WebView dataSource;
    private LinearLayout layout_data;
    private LinearLayout layout_error;
    private LinearLayout layout_holder;
    private LinearLayout layout_loading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_viewer);
        initializeBookData();

        bindComponents();
        setWebViewSettings();
        setupInterface(false);
        setListeners();
    }

    private void bindComponents(){
        layout_data = findViewById(R.id.book_viewer_layout);
        layout_error = findViewById(R.id.book_viewer_loading_error);
        layout_holder = findViewById(R.id.book_viewer_holder_layout);
        layout_loading = findViewById(R.id.book_viewer_loading_layout);

        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private void initializeBookData(){
        bookData = getIntent().getStringExtra("code");
        if (bookData == null) bookData = "";
    }

    @SuppressLint("AddJavascriptInterface")
    private void setWebViewSettings(){
        dataSource = new WebView(this);
        GlobalConstants.configureStandardWebView(dataSource);
        dataSource.setWebViewClient(new DetailsWebClient(this));
        dataSource.addJavascriptInterface(new DetailsJSInterface(this), "js_api");
        dataSource.loadUrl(GlobalConstants.URL_LIBRARY_DETAILS + "?codigo=" + bookData
                + GlobalConstants.MANDATORY_APPEND_URL_LIBRARY_DETAILS);
    }

    public void setupInterface(boolean setResults){
        if (setResults){
            FrameLayout.LayoutParams noGravity = (FrameLayout.LayoutParams)layout_holder.getLayoutParams();
            noGravity.gravity = Gravity.NO_GRAVITY;
            layout_holder.setLayoutParams(noGravity);
            layout_data.setVisibility(View.VISIBLE);
            layout_loading.setVisibility(View.GONE);
        }
        else{
            FrameLayout.LayoutParams gravity = (FrameLayout.LayoutParams)layout_holder.getLayoutParams();
            gravity.gravity = Gravity.CENTER;
            layout_holder.setLayoutParams(gravity);
            layout_data.setVisibility(View.GONE);
            layout_loading.setVisibility(View.VISIBLE);
        }
        layout_error.setVisibility(View.GONE);
    }

    public void setErrorForm(String description){
        layout_data.setVisibility(View.GONE);
        layout_loading.setVisibility(View.GONE);
        layout_error.setVisibility(View.VISIBLE);
        ((TextView)findViewById(R.id.book_viewer_error_text)).setText(getString(R.string.label_book_details_connection_error, description));
    }

    private void setListeners(){
        findViewById(R.id.book_viewer_button_reload).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setupInterface(false);
                dataSource.reload();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void setBookData(String jsObject){
        try {
            JSONObject book_properties = new JSONObject(jsObject);
            if (!book_properties.getBoolean("exists"))
                return;

            new DownloadImageTask((ImageView) findViewById(R.id.image_details_book_cover))
                    .execute(GlobalConstants.URL_LIBRARY_BOOK_COVER +
                            GlobalConstants.MANDATORY_APPEND_URL_LIBRARY_BOOK_COVER + book_properties.getString("code"));

            ((TextView)findViewById(R.id.label_book_title)).setText(book_properties.getString("title"));
            ((TextView)findViewById(R.id.label_book_author)).setText(book_properties.getString("author"));

            int hMargin = (int)(getResources().getDimension(R.dimen.form_items_default_margin ));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            params.setMargins(0, hMargin, 0, 0);

            float headerSize = getResources().getDimension(R.dimen.label_form_title_def_size);
            float descriptionSize = getResources().getDimension(R.dimen.label_form_item_def_size);

            JSONArray properties = book_properties.getJSONArray("properties");
            for (int i = 0; i < properties.length(); ++i){
                JSONObject cProperty = properties.getJSONObject(i);

                TextView header = new TextView(this);
                TextView description = new TextView(this);

                header.setText(cProperty.getString("title"));
                description.setText(cProperty.getString("description"));

                header.setTypeface(header.getTypeface(), Typeface.BOLD);
                header.setTextSize(TypedValue.COMPLEX_UNIT_PX, headerSize);
                header.setLayoutParams(params);

                description.setTextSize(TypedValue.COMPLEX_UNIT_PX, descriptionSize);

                layout_data.addView(header);
                layout_data.addView(description);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
