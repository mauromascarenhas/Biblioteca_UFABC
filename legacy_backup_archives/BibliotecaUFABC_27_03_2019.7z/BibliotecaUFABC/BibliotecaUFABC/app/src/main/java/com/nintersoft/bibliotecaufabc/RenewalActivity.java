package com.nintersoft.bibliotecaufabc;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.nintersoft.bibliotecaufabc.constants.GlobalConstants;
import com.nintersoft.bibliotecaufabc.jsinterface.RenewalJSInterface;
import com.nintersoft.bibliotecaufabc.webviewclients.RenewalWebClient;

import java.util.ArrayList;

public class RenewalActivity extends AppCompatActivity {

    private WebView dataSource;
    private RecyclerView result_list;
    private LinearLayout layout_error;
    private LinearLayout layout_holder;
    private LinearLayout layout_loading;

//    private SearchBookAdapter adapter;
//    private ArrayList<BookProperties> availableBooks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_renewal);

        setWebViewSettings();
        bindComponents();
        setupInterface(false);
        setListeners();
    }

    private void bindComponents(){
        result_list = findViewById(R.id.list_renewal_results);
        layout_error = findViewById(R.id.renewal_error_layout);
        layout_holder = findViewById(R.id.renewal_holder_layout);
        layout_loading = findViewById(R.id.renewal_loading_layout);

        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    public void setupInterface(boolean setResults){
        if (setResults){
            FrameLayout.LayoutParams noGravity = (FrameLayout.LayoutParams)layout_holder.getLayoutParams();
            noGravity.gravity = Gravity.NO_GRAVITY;
            layout_holder.setLayoutParams(noGravity);
            result_list.setVisibility(View.VISIBLE);
            layout_loading.setVisibility(View.GONE);
        }
        else{
            FrameLayout.LayoutParams gravity = (FrameLayout.LayoutParams)layout_holder.getLayoutParams();
            gravity.gravity = Gravity.CENTER;
            layout_holder.setLayoutParams(gravity);
            result_list.setVisibility(View.GONE);
            layout_loading.setVisibility(View.VISIBLE);
        }
        layout_error.setVisibility(View.GONE);
    }

    public void setErrorForm(String description){
        result_list.setVisibility(View.GONE);
        layout_loading.setVisibility(View.GONE);
        layout_error.setVisibility(View.VISIBLE);
        ((TextView)findViewById(R.id.renewal_connection_error_text)).setText(getString(R.string.label_renewal_connection_error, description));
    }

    private void setListeners() {
        findViewById(R.id.button_renewal_reload).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setupInterface(false);
                dataSource.loadUrl(GlobalConstants.URL_LIBRARY_RENEWAL);
            }
        });
    }

    @SuppressLint("AddJavascriptInterface")
    private void setWebViewSettings(){
        dataSource = new WebView(this);
        GlobalConstants.configureStandardWebView(dataSource);
        dataSource.setWebViewClient(new RenewalWebClient(this));
        dataSource.addJavascriptInterface(new RenewalJSInterface(this), "js_api");
        dataSource.loadUrl(GlobalConstants.URL_LIBRARY_RENEWAL);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
