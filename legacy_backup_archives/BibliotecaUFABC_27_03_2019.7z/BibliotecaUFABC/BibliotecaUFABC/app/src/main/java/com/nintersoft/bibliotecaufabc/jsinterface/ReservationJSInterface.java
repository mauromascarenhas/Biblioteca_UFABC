package com.nintersoft.bibliotecaufabc.jsinterface;

import android.content.Context;
import android.webkit.JavascriptInterface;

public class ReservationJSInterface {
    private Context mContext;

    public ReservationJSInterface(Context context){
        mContext = context;
    }

    @JavascriptInterface
    public void setReservationBooks(String books){
        //TODO: Do whatever it has to do here
    }
}
