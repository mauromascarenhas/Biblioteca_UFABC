package com.nintersoft.bibliotecaufabc.jsinterface;

import android.content.Context;
import android.webkit.JavascriptInterface;

public class RenewalJSInterface {
    private Context mContext;

    public RenewalJSInterface(Context context){
        mContext = context;
    }

    @JavascriptInterface
    public void setRenewals(String books){
        //
    }
}
