package com.nintersoft.bibliotecaufabc;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.MenuItem;
import android.webkit.WebView;

import com.nintersoft.bibliotecaufabc.constants.GlobalConstants;
import com.nintersoft.bibliotecaufabc.jsinterface.ReservationJSInterface;
import com.nintersoft.bibliotecaufabc.webviewclients.ReservationWebClient;

public class ReservationActivity extends AppCompatActivity {

    private WebView dataSource;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation);

        bindComponents();
        setWebViewSettings();
    }

    private void bindComponents(){
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @SuppressLint("AddJavascriptInterface")
    private void setWebViewSettings(){
        dataSource = new WebView(this);
        GlobalConstants.configureStandardWebView(dataSource);
        dataSource.setWebViewClient(new ReservationWebClient(this));
        dataSource.addJavascriptInterface(new ReservationJSInterface(this), "js_api");
        dataSource.loadUrl(GlobalConstants.URL_LIBRARY_RESERVATION);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
