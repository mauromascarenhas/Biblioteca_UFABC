package com.nintersoft.bibliotecaufabc.notification;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.nintersoft.bibliotecaufabc.book_renewal_model.BookRenewalContract;
import com.nintersoft.bibliotecaufabc.book_renewal_model.BookRenewalDAO;
import com.nintersoft.bibliotecaufabc.book_renewal_model.BookRenewalDatabase;
import com.nintersoft.bibliotecaufabc.constants.GlobalConstants;

import androidx.room.Room;

public class NotificationBootScheduler extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        BookRenewalDAO dao = Room.databaseBuilder(context, BookRenewalDatabase.class,
                            BookRenewalContract.DB_NAME).allowMainThreadQueries().build().bookRenewalDAO();

        GlobalConstants.createNotificationChannel(context.getApplicationContext());
        GlobalConstants.scheduleRenewalAlarms(context, dao);
    }
}
