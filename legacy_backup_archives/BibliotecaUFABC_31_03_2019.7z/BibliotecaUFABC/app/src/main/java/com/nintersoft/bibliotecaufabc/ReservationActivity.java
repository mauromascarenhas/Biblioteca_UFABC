package com.nintersoft.bibliotecaufabc;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.nintersoft.bibliotecaufabc.constants.GlobalConstants;
import com.nintersoft.bibliotecaufabc.jsinterface.ReservationJSInterface;
import com.nintersoft.bibliotecaufabc.webviewclients.ReservationWebClient;

public class ReservationActivity extends AppCompatActivity {

    private WebView dataSource;
    private RecyclerView result_list;
    private LinearLayout layout_error;
    private LinearLayout layout_holder;
    private LinearLayout layout_loading;
    private LinearLayout layout_no_books;

//    private SearchBookAdapter adapter;
//    private ArrayList<BookProperties> availableBooks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation);

        setWebViewSettings();
        bindComponents();
        setupInterface(false);
        setListeners();
    }

    private void bindComponents(){
        result_list = findViewById(R.id.list_reservation_results);
        layout_error = findViewById(R.id.reservation_error_layout);
        layout_holder = findViewById(R.id.reservation_holder_layout);
        layout_loading = findViewById(R.id.reservation_loading_layout);
        layout_no_books = findViewById(R.id.no_reservation_books_layout);

        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    public void setupInterface(boolean setResults){
        if (setResults){
            FrameLayout.LayoutParams noGravity = (FrameLayout.LayoutParams)layout_holder.getLayoutParams();
            noGravity.gravity = Gravity.NO_GRAVITY;
            layout_holder.setLayoutParams(noGravity);
            result_list.setVisibility(View.VISIBLE);
            layout_loading.setVisibility(View.GONE);
        }
        else{
            FrameLayout.LayoutParams gravity = (FrameLayout.LayoutParams)layout_holder.getLayoutParams();
            gravity.gravity = Gravity.CENTER;
            layout_holder.setLayoutParams(gravity);
            result_list.setVisibility(View.GONE);
            layout_loading.setVisibility(View.VISIBLE);
        }
        layout_error.setVisibility(View.GONE);
        layout_no_books.setVisibility(View.GONE);
    }

    public void setErrorForm(String description){
        result_list.setVisibility(View.GONE);
        layout_loading.setVisibility(View.GONE);
        layout_no_books.setVisibility(View.GONE);
        layout_error.setVisibility(View.VISIBLE);
        ((TextView)findViewById(R.id.reservation_connection_error_text)).setText(getString(R.string.label_reservation_connection_error, description));
    }

    public void setUserNameNoReservation(String userName){
        result_list.setVisibility(View.GONE);
        layout_error.setVisibility(View.GONE);
        layout_loading.setVisibility(View.GONE);
        layout_no_books.setVisibility(View.VISIBLE);
        ((TextView)findViewById(R.id.no_reservation_username)).setText(getString(R.string.label_no_reservation_username, userName));
    }

    private void setListeners() {
        findViewById(R.id.button_reservation_reload).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setupInterface(false);
                dataSource.loadUrl(GlobalConstants.URL_LIBRARY_RESERVATION);
            }
        });
    }

    @SuppressLint("AddJavascriptInterface")
    private void setWebViewSettings(){
        dataSource = new WebView(this);
        GlobalConstants.configureStandardWebView(dataSource);
        dataSource.setWebViewClient(new ReservationWebClient(this));
        dataSource.addJavascriptInterface(new ReservationJSInterface(this), "js_api");
        dataSource.loadUrl(GlobalConstants.URL_LIBRARY_RESERVATION);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
