package com.nintersoft.bibliotecaufabc;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.nintersoft.bibliotecaufabc.bookproperties.BookProperties;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class SearchBookAdapter extends RecyclerView.Adapter<SearchBookAdapter.SearchBooksViewHolder> {

    public static class SearchBooksViewHolder extends RecyclerView.ViewHolder{
        TextView author;
        TextView section;
        TextView title;
        TextView type;

        public SearchBooksViewHolder(View v){
            super(v);

            type = v.findViewById(R.id.card_item_type);
            title = v.findViewById(R.id.card_item_title);
            author = v.findViewById(R.id.card_item_author);
            section = v.findViewById(R.id.card_item_section);
        }
    }

    private Context mContext;
    private ArrayList<BookProperties> properties;

    public SearchBookAdapter(@NonNull Context context,@NonNull ArrayList<BookProperties> properties){
        this.properties = properties;
        mContext = context;
    }

    public void populateView(int a){
        for (int i = 0; i < a; ++i){
            BookProperties c = new BookProperties();
            c.setAuthor("Author " + String.valueOf(i));
            c.setSection("Section " + String.valueOf(i));
            c.setTitle("Title " + String.valueOf(i));
            c.setType("Type " + String.valueOf(i));
            properties.add(c);
        }
    }

    @NonNull
    @Override
    public SearchBooksViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new SearchBooksViewHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item_book_properties, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull SearchBooksViewHolder holder, int position) {
        BookProperties cProperties = properties.get(position);

        holder.type.setText(cProperties.getType());
        holder.title.setText(cProperties.getTitle());
        holder.author.setText(cProperties.getAuthor());
        holder.section.setText(cProperties.getSection());
    }

    @Override
    public int getItemCount() {
        return properties.size();
    }

}
