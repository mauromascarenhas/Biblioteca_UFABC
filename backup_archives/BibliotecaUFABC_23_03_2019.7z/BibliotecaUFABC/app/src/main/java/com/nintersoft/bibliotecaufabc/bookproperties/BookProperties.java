package com.nintersoft.bibliotecaufabc.bookproperties;

import android.graphics.Bitmap;

public class BookProperties {
    private Bitmap cover;
    private String title;
    private String author;
    private String type;
    private String section;

    public BookProperties(){

    }

    public Bitmap getCover() {
        return cover;
    }

    public void setCover(Bitmap cover) {
        this.cover = cover;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }
}
