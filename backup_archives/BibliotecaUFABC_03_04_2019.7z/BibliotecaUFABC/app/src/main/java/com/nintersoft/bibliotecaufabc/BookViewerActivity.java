package com.nintersoft.bibliotecaufabc;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.nintersoft.bibliotecaufabc.constants.GlobalConstants;
import com.nintersoft.bibliotecaufabc.jsinterface.DetailsJSInterface;
import com.nintersoft.bibliotecaufabc.webviewclients.DetailsWebClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class BookViewerActivity extends AppCompatActivity {

    private String bookData;

    private WebView dataSource;
    private MenuItem share_action;
    private LinearLayout layout_data;
    private LinearLayout layout_error;
    private LinearLayout layout_holder;
    private LinearLayout layout_loading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_viewer);
        initializeBookData();

        bindComponents();
        setWebViewSettings();
        setupInterface(false);
        setListeners();
    }

    private void bindComponents(){
        layout_data = findViewById(R.id.book_viewer_layout);
        layout_error = findViewById(R.id.book_viewer_loading_error);
        layout_holder = findViewById(R.id.book_viewer_holder_layout);
        layout_loading = findViewById(R.id.book_viewer_loading_layout);

        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private void initializeBookData(){
        Intent data = getIntent();
        bookData = data.getStringExtra("code");
        if (bookData == null) bookData = "";
    }

    @SuppressLint("AddJavascriptInterface")
    private void setWebViewSettings(){
        dataSource = new WebView(this);
        GlobalConstants.configureStandardWebView(dataSource);
        dataSource.setWebViewClient(new DetailsWebClient(this));
        dataSource.addJavascriptInterface(new DetailsJSInterface(this), "js_api");
        dataSource.loadUrl(GlobalConstants.URL_LIBRARY_DETAILS + "?codigo=" + bookData
                + GlobalConstants.MANDATORY_APPEND_URL_LIBRARY_DETAILS);
    }

    public void setupInterface(boolean setResults){
        if (setResults){
            FrameLayout.LayoutParams noGravity = (FrameLayout.LayoutParams)layout_holder.getLayoutParams();
            noGravity.gravity = Gravity.NO_GRAVITY;
            layout_holder.setLayoutParams(noGravity);
            layout_data.setVisibility(View.VISIBLE);
            layout_loading.setVisibility(View.GONE);
        }
        else{
            FrameLayout.LayoutParams gravity = (FrameLayout.LayoutParams)layout_holder.getLayoutParams();
            gravity.gravity = Gravity.CENTER;
            layout_holder.setLayoutParams(gravity);
            layout_data.setVisibility(View.GONE);
            layout_loading.setVisibility(View.VISIBLE);
        }
        layout_error.setVisibility(View.GONE);
    }

    public void setErrorForm(String description){
        layout_data.setVisibility(View.GONE);
        layout_loading.setVisibility(View.GONE);
        layout_error.setVisibility(View.VISIBLE);
        ((TextView)findViewById(R.id.book_viewer_error_text)).setText(getString(R.string.label_book_details_connection_error, description));
    }

    private void setListeners(){
        findViewById(R.id.book_viewer_button_reload).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setupInterface(false);
                dataSource.reload();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_book_details, menu);

        share_action = menu.findItem(R.id.action_share_book);
        share_action.setVisible(false);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home :
                finish();
                return true;
            case R.id.action_share_book:
                String bookShare = getString(R.string.share_book_structure,
                        ((TextView)findViewById(R.id.label_book_title)).getText().toString(),
                        ((TextView)findViewById(R.id.label_book_author)).getText().toString(),
                        GlobalConstants.URL_LIBRARY_DETAILS + "?codigo=" + bookData
                                + GlobalConstants.MANDATORY_APPEND_URL_LIBRARY_DETAILS);

                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT, bookShare);
                if (share.resolveActivity(getPackageManager()) != null)
                    startActivity(Intent.createChooser(share, getString(R.string.intent_share_book)));
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void setBookData(String jsObject){
        try {
            JSONObject book_properties = new JSONObject(jsObject);
            if (!book_properties.getBoolean("exists"))
                return;

            Glide.with(getApplicationContext())
                    .load(GlobalConstants.URL_LIBRARY_BOOK_COVER +
                            GlobalConstants.MANDATORY_APPEND_URL_LIBRARY_BOOK_COVER + book_properties.getString("code"))
                    .placeholder(R.drawable.ic_default_book)
                    .diskCacheStrategy(DiskCacheStrategy.ALL).into((ImageView) findViewById(R.id.image_details_book_cover));

            ((TextView)findViewById(R.id.label_book_title)).setText(book_properties.getString("title"));
            ((TextView)findViewById(R.id.label_book_author)).setText(book_properties.getString("author"));

            int dMargin = (int)(getResources().getDimension(R.dimen.form_items_default_margin));
            LinearLayout.LayoutParams defParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            defParams.setMargins(0, dMargin, 0, 0);

            int hMargin = (int)(getResources().getDimension(R.dimen.form_header_default_margin));
            LinearLayout.LayoutParams hParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            hParams.setMargins(0, hMargin, 0, hMargin);
            hParams.gravity = Gravity.CENTER_HORIZONTAL;

            float headerSize = getResources().getDimension(R.dimen.label_form_title_def_size);
            float descriptionSize = getResources().getDimension(R.dimen.label_form_item_def_size);

            JSONArray properties = book_properties.getJSONArray("properties");
            for (int i = 0; i < properties.length(); ++i){
                JSONObject cProperty = properties.getJSONObject(i);

                TextView header = new TextView(this);
                TextView description = new TextView(this);

                header.setText(cProperty.getString("title"));
                description.setText(cProperty.getString("description"));

                header.setTypeface(header.getTypeface(), Typeface.BOLD);
                header.setTextSize(TypedValue.COMPLEX_UNIT_PX, headerSize);
                header.setLayoutParams(defParams);

                description.setTextSize(TypedValue.COMPLEX_UNIT_PX, descriptionSize);

                layout_data.addView(header);
                layout_data.addView(description);
            }

            JSONArray mediaContent = book_properties.getJSONArray("media");
            if (mediaContent.length() > 0){
                for (int i = 0; i < mediaContent.length(); ++i){
                    JSONObject cMedia = mediaContent.getJSONObject(i);

                    TextView header = new TextView(this);
                    header.setText(cMedia.getString("type"));
                    header.setGravity(Gravity.CENTER_HORIZONTAL);
                    header.setTypeface(header.getTypeface(), Typeface.BOLD);
                    header.setTextSize(TypedValue.COMPLEX_UNIT_PX, headerSize);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1)
                        header.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                    header.setLayoutParams(hParams);
                    layout_data.addView(header);

                    JSONArray mediaContentValues = cMedia.getJSONArray("values");
                    for (int j = 0; j < mediaContentValues.length(); ++j){
                        JSONObject cValue = mediaContentValues.getJSONObject(i);

                        TextView description = new TextView(this);
                        description.setText(String.format("%1$s %2$s", "\u23E9 ", cValue.getString("text").toUpperCase()));
                        description.setTextSize(TypedValue.COMPLEX_UNIT_PX, descriptionSize);
                        description.setTextColor(getResources().getColor(R.color.colorLink));

                        final String link = cValue.getString("link");
                        if (!link.isEmpty()) {
                            description.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    AlertDialog.Builder builder = new AlertDialog.Builder(BookViewerActivity.this);
                                    builder.setTitle(R.string.dialog_warning_title);
                                    builder.setMessage(getString(R.string.dialog_warning_message_external_link, link));
                                    builder.setPositiveButton(R.string.dialog_button_ok, new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            Intent browser = new Intent(Intent.ACTION_VIEW);
                                            browser.setData(Uri.parse(link));
                                            if (browser.resolveActivity(getPackageManager()) != null)
                                                startActivity(browser);
                                        }
                                    });
                                    builder.setNegativeButton(R.string.dialog_button_cancel, null);
                                    builder.create().show();
                                }
                            });
                        }

                        layout_data.addView(description);
                    }
                }
            }

            JSONArray copies = book_properties.getJSONArray("copies");
            if (copies.length() > 0){
                TextView header = new TextView(this);
                header.setText(R.string.label_book_details_available_header);
                header.setGravity(Gravity.CENTER_HORIZONTAL);
                header.setTypeface(header.getTypeface(), Typeface.BOLD);
                header.setTextSize(TypedValue.COMPLEX_UNIT_PX, headerSize);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1)
                    header.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                header.setLayoutParams(hParams);
                layout_data.addView(header);

                for (int i = 0; i < copies.length(); ++i){
                    JSONObject cValue = copies.getJSONObject(i);

                    TextView description = new TextView(this);
                    description.setText(getString(R.string.label_book_details_available_details,
                            cValue.getString("copies").replace("de", getString(R.string.label_book_details_available_counting_sep)),
                            cValue.getString("library")));
                    description.setTextSize(TypedValue.COMPLEX_UNIT_PX, descriptionSize);
                    description.setTextColor(getResources().getColor(R.color.colorLibrary));

                    layout_data.addView(description);
                }
            }

            if (GlobalConstants.isUserConnected && book_properties.getBoolean("reservable")) {
                Button button_reserve = new Button(this);
                button_reserve.setText(R.string.button_book_details_reserve);
                button_reserve.setLayoutParams(hParams);

                button_reserve.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // TODO : On click listener
                    }
                });

                layout_data.addView(button_reserve);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        } finally {
            share_action.setVisible(true);
        }
    }
}
