package com.nintersoft.bibliotecaufabc.jsinterface;

import android.content.Context;
import android.webkit.JavascriptInterface;

import com.nintersoft.bibliotecaufabc.RenewalActivity;

public class RenewalJSInterface {
    private Context mContext;

    public RenewalJSInterface(Context context){
        mContext = context;
    }

    @JavascriptInterface
    public void setRenewals(String books){
        //
    }

    @JavascriptInterface
    public void setUsernameErr(final String name){
        ((RenewalActivity)mContext).runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ((RenewalActivity)mContext).setUserNameNoRenewal(name);
            }
        });
    }
}
