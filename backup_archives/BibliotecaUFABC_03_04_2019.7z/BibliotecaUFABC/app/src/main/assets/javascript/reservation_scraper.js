function getReservations(){
    var errorDiv = document.querySelector('.divErroCentralizada');
    if (errorDiv != null){
        js_api.setUsernameErr(errorDiv.getElementsByTagName('b')[0].textContent);
        return;
    }

    var list = document.querySelector('ul[data-theme=c]');
    //TODO: Do whatever I have to do here!
}