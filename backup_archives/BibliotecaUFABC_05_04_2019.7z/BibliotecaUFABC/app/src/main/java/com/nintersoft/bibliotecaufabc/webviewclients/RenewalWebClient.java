package com.nintersoft.bibliotecaufabc.webviewclients;

import android.content.Context;
import android.os.Build;
import android.util.Log;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.nintersoft.bibliotecaufabc.RenewalActivity;
import com.nintersoft.bibliotecaufabc.constants.GlobalConstants;

import androidx.annotation.RequiresApi;

public class RenewalWebClient extends WebViewClient {
    private int renewal_page_finished;

    private Context mContext;

    public RenewalWebClient(Context context){
        super();
        this.mContext = context;
        renewal_page_finished = 0;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        return false;
    }

    @Override
    public boolean shouldOverrideUrlLoading(WebView view, String url) {
        return false;
    }

    @Override
    public void onPageFinished(WebView view, String url) {
        super.onPageFinished(view, url);

        if (renewal_page_finished < 1){
            renewal_page_finished++;
            return;
        }

        if (url.contains(GlobalConstants.URL_LIBRARY_RENEWAL)){
            String script = String.format("javascript: %1$s \ngetRenewals();",
                    GlobalConstants.getScriptFromAssets(mContext, "javascript/renewal_scraper.js"));
            GlobalConstants.executeScript(view, script);
            Log.d("RENEWAL_URL", url);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
        ((RenewalActivity)mContext).setErrorForm(error.getDescription().toString());
        super.onReceivedError(view, request, error);
    }

    @Override
    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
        ((RenewalActivity)mContext).setErrorForm(description);
        super.onReceivedError(view, errorCode, description, failingUrl);
    }
}
