function getRenewals(){
    var errorDiv = document.querySelector('.divErroCentralizada');
    if (errorDiv != null){
        js_api.setUsernameErr(errorDiv.getElementsByTagName('b')[0].textContent);
        return;
    }

    //TODO: Do whatever I have to do here!
}